<?php
// Copiar a config.php y editar
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'asociacion_db',
        'user' => 'asoc_user',
        'pass' => 'change_me'
    ],
    'base_url' => 'http://localhost/asociacion', // sin barra final
    'session_name' => 'asoc_session',
    'admin_default_password' => 'admin123',
];
